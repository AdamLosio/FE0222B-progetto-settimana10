export interface Todo {
  id:number
  titolo:string
  completed:boolean
}
