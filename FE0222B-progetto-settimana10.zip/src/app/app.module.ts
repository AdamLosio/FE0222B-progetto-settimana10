import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { TodosComponent } from './components/todos/todos.component';

import { FormsModule } from '@angular/forms';
import { CompletedComponent } from './components/completed/completed.component';
import { RouterModule, Routes } from '@angular/router';


@NgModule({
  declarations: [
    AppComponent,
    TodosComponent,
    CompletedComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
RouterModule.forRoot([])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
